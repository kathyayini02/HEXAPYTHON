class CustomerDAO:
    def insert_customer(self, customer): pass
    def get_customer_by_id(self, customer_id): pass
    def update_customer(self, customer): pass
    def delete_customer(self, customer_id): pass
    def get_all_customers(self): pass
