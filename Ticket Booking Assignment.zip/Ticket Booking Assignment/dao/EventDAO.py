class EventDAO:
    def insert_event(self, event): pass
    def get_event_by_id(self, event_id): pass
    def update_event(self, event): pass
    def delete_event(self, event_id): pass
    def get_all_events(self): pass
