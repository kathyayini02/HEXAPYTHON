class VenueDAO:
    def insert_venue(self, venue): pass
    def get_venue_by_id(self, venue_id): pass
    def update_venue(self, venue): pass
    def delete_venue(self, venue_id): pass
    def get_all_venues(self): pass
