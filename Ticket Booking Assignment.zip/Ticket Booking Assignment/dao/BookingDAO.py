class BookingDAO:
    def insert_booking(self, booking): pass
    def get_booking_by_id(self, booking_id): pass
    def update_booking(self, booking): pass
    def delete_booking(self, booking_id): pass
    def get_all_bookings(self): pass
