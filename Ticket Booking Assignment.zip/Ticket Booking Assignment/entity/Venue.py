class Venue:
    def __init__(self, venue_id=None, venue_name="", address=""):
        self.venue_id = venue_id
        self.venue_name = venue_name
        self.address = address
